%vim set syntax=prolog

muz(sokrates).
smrtelny(X) :- muz(X).

% dotaz na smrtelnost Sokrata (odpoved bude true)
% smrtelny(Sokrates)


