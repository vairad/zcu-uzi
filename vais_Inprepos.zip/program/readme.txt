V odevzdaném souboru inprepos.pl realizuji úlohu v prologu zadání č. 13

Zadání číslo 13:
Ralizujte program v Prologu, kterým pro zadané aritmetické výrazy otestujete,  zda  jsou  zapsány  
v prefixové,  infixové nebo  postfixové formě (formátu). 

Program se po překladu spustí predikátem "start.".
K testování lze použít výrazy ze souboru testovaci_data.txt.

K ověření formy aritmetického výrazu slouží predikáty infix([...]), prefix([...]) a postfix([...]).

