Ve složce build je přpraven Makefile pro gcc, výstupem je soubor Mastermind.exe. Testovaný v OS Linux.
Ve složce bin jsou připraveny přeložené 64-bitové binární verze programu. (Mastermind pro Linux a Mastermind.exe pro Windows)
Ve složce Mastermind jsou zdrojové kódy k aplikaci.

Doporučené omezení vstupních parametrů je 6 barev a 6 pozic.
Z důvodů přenositelnosti byla maximální hodnota zadávaná v interaktivním režimu omezena na 10000 (namísto UINT_MAX).

