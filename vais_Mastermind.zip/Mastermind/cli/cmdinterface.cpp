#include <stdlib.h>
#include <limits.h>
#include <algorithm>

#include "cli/cmdinterface.h"

/**
 * Metoda nacita pouze cisla v rozsahu unsigned int
 * @brief CMDInterface::getCount
 * @return nactene cislo
 */
unsigned int CMDInterface::getUInt(){
    unsigned long number = 20000;
    std::string numbuf;

    std::cout << "Zadej cislo (doporuceno 5): "<< "\n";

    while(number > 10000){
        std::cin >> numbuf;

        number = strtoul(numbuf.c_str(), 0, 10); //prevod z ascii na long

        if (ULONG_MAX == number && ERANGE == errno){ // pokud pretece u long
            std::cout << "cislo je moc velke" << "\n";
            continue;
        }
        if(number > 10000){ // pokud je vyssi nez uint
            std::cout << "cislo je moc velke" << "\n";
            continue;
        }
    }

    std::cout << "Zadano: " << number << "\n" << "\n";
    return (unsigned int)number;
}

/**
 * Metoda vytiskne vyzvu zadani poctu barev a spusti metodu pro nacteni cisla @code{getCount}
 * @brief CMDInterface::getColorsCount
 * @return nactene cislo
 */
unsigned int CMDInterface::getColorsCount(){
    std::cout << "Zadej pocet barev" << "\n";
    return getUInt();
}

/**
 * Metoda vytiskne vyzvu zadani poctu pozic a spusti metodu pro nacteni cisla @code{getCount}
 * @brief CMDInterface::getPlacesCount
 * @return nacteni cslo
 */
unsigned int CMDInterface::getPlacesCount(){
    std::cout << "Zadej pocet pozic" << "\n";
    return getUInt();
}

//###############################################################

/**
 * Metoda nacte pouze znaky symbolizujici typ hry: C / P
 * @brief CMDInterface::getGameType
 * @return char C / P
 */
char CMDInterface::getGameType(){
    std::cout << "Zadej typ hry." << "\n";
    std::cout << "Pro ohodnoceni pocitacem - C" << "\n";
    std::cout << "Pro ohodnoceni uzivatelem - P" << "\n";

    char read = 0;
    while(read != 'C' && read != 'P'){
        std::cin >> read;
    }
    std::cout << "Zadano: " << read << "\n" << "\n";
    return read;
}

/**
 * Metoda nacte pouze znaky symbolizujici pokracivani vehre: A / N
 * @brief CMDInterface::getNextRound
 * @return char A / N
 */
char CMDInterface::getNextRound(){
    std::cout << "\n";
    std::cout << "Chcetepokracovat dalsim kolem?" << "\n";
    std::cout << "Pro pokracivani zadej - (A)no" << "\n";
    std::cout << "Pro ukonceni - (N)e" << "\n";

    char read = 0;
    while(read != 'A' && read != 'N'){
        std::cin >> read;
    }

    std::cout << "Zadano: " << read << "\n";
    return read;
}

//###################################################################################################################x

/**
 * Odradkuje dle zadaneho poctu
 * @brief CMDInterface::spacing
 * @param lines pocet volnych radek
 */
void CMDInterface::spacing(int lines){
    int n = 0;
    while(n < lines){
       std::cout << "\n";
       n++;
    }
}


/**
 * Nacte vstup oduzivatele a seradi hodnoty true/false v poradi false ... true
 * @brief DataControler::readClues
 * @return sorted list of clues to solve mastermind
 */
std::vector<bool> CMDInterface::readClues(){
    std::vector<bool> clues;

    std::cout << "Zadej ohodnoceni 1 nebo 0 (zadavani ukoncte znakem N)" << "\n";

    char read = 0;
    while(read != 'N'){
        std::cout << "ohodnoceni (1/0/N): " ;
        std::cin >> read;
        if(read == '0'){
            clues.push_back(false);
        }
        if(read == '1'){
            clues.push_back(true);
        }
    }
    sort(clues.begin(), clues.end());
    std::cout << "\n";

    printClue(clues);

    return clues;
}


/***************************************** Nasledujici metody tisknou dialog se strojem */

/**
 * Vytiskne hodnoty barev do radky vedle sebe v nezmenenem poradi.
 * @brief CMDInterface::printColors
 * @param guess_colors
 */
void CMDInterface::printColors(std::vector<unsigned int> guess_colors)
{
    for(unsigned int i = 0; i < guess_colors.size(); ++i)
    {
        std::cout  << "\t" << guess_colors.at(i) << " ";
    }
    std::cout << "\n";
}

/**
 * Vytiskne ohodnoceni pokusu
 * @brief CMDInterface::printColors
 * @param guess_colors
 */
void CMDInterface::printClue(std::vector<bool> clues)
{
    std::cout << "Ohodnoceni tahu je: ";
    for(unsigned int i = 0; i < clues.size(); ++i)
    {
        std::cout << " " << clues.at(i);
    }

    std::cout << "\n";
}


/**
 * Vytiskne libovolnou predanou zpravu.
 * @brief CMDInterface::print
 * @param msg
 */
void CMDInterface::print(std::string msg){
    std::cout << msg  << "\n";
}

/**
 * Úvodni informace o hre.
 * @brief CMDInterface::printInfo
 */
void CMDInterface::printInfo(){
    std::cout << "Vitejte v programu AutoMASTERMIND" << "\n";
    std::cout << "Tento program demonstruje automaticke strojove reseni logicke hry Mastermind." << "\n";
    std::cout << "Jde o algoritmus Donalda Knutha (1977), ktery redukuje mnozinu vsech reseni za pomoci entropie informace." << "\n";
    std::cout << "\n";
    std::cout << "Jsou k dispozici dva rezimy hry:" << "\n";
    std::cout << "\t 1)Ohodnoceni tahu urcuje pocitac" << "\n";
    std::cout << "\t 2)Ohodnoceni tahu urcuje uzivatel" << "\n";
    std::cout << "\t \t Pro ohodnoceni slouzi znaky 1 a 0" << "\n";
    std::cout << "\t \t 1 - symbolizuje spravnou barvu na spravnem miste" << "\n";
    std::cout << "\t \t 0 - symbolizuje spravnou barvu na spatnem miste" << "\n";
}

/**
 * Úvodni informace pri automaticke hre.
 * @brief CMDInterface::printAutoInfo
 */
void CMDInterface::printAutoInfo(){
    std::cout << "Vitejte v programu AutoMASTERMIND" << "\n";
    std::cout << "Tento program demonstruje automaticke strojove reseni logicke hry Mastermind." << "\n";
    std::cout << "Jde o algoritmus Donalda Knutha (1977), ktery redukuje mnozinu vsech reseni za pomoci entropie informace." << "\n";
    std::cout << "\n";
    std::cout << "Hra je v automatickem rezimu" << "\n";
    std::cout << "Ohodnoceni tahu:" << "\n";
    std::cout << "\t 1 - symbolizuje spravnou barvu na spravnem miste" << "\n";
    std::cout << "\t 0 - symbolizuje spravnou barvu na spatnem miste" << "\n";
}

/**
 * Informace o novem kole
 * @brief CMDInterface::newGame
 */
void CMDInterface::newGame(){
    spacing(3);
    std::cout << "Nova hra prave zacina:" << "\n";
}

void CMDInterface::thinking(){
    std::cout << " ... Premyslim ..."  << "\n";
}

void CMDInterface::strategy(){
    std::cout << " Priravuji seznam reseni..." << "\n";
}

void CMDInterface::congratulation(){
    std::cout << "\n";
    std::cout << "Hlavolam byl uspesne vyresen!" << "\n";
}

void CMDInterface::guess(){
    std::cout << "\n";
    std::cout << "Odhaduji:" << "\n";
}

void CMDInterface::show(){
    std::cout << "\n";
    std::cout << "Ma kombinace byla:" << "\n";
}

void CMDInterface::badPlayer(){
    std::cout << "\n";
    std::cout << "To neni mozne!" << "\n";
    std::cout << "Opravdu jste zadal spravne ohodnoceni?!" << "\n";
    std::cout << "\n";
}
